import {S3Client,PutObjectCommand,GetObjectCommand,HeadBucketCommand,CreateBucketCommand} from '@aws-sdk/client-s3';
const bucket=process.env.S3_BUCKET??'knowverse';
const s3=new S3Client({endpoint:process.env.S3_ENDPOINT,region:process.env.S3_REGION??'us-east-1',forcePathStyle:process.env.S3_FORCE_PATH_STYLE!=='false',credentials:{accessKeyId:process.env.S3_ACCESS_KEY??'',secretAccessKey:process.env.S3_SECRET_KEY??''}});
export async function ensureBucket(){try{await s3.send(new HeadBucketCommand({Bucket:bucket}))}catch(e){if(e.name==='NotFound'||e.$metadata?.httpStatusCode===404)await s3.send(new CreateBucketCommand({Bucket:bucket}));else throw e}}
export async function store(key,body,type='application/octet-stream'){await s3.send(new PutObjectCommand({Bucket:bucket,Key:key,Body:body,ContentType:type}));return key}
export async function load(key){const result=await s3.send(new GetObjectCommand({Bucket:bucket,Key:key}));return Buffer.from(await result.Body.transformToByteArray())}
