import {Auth} from '@/components/Auth';export default function Login(){return <Auth kind="login"/>}
